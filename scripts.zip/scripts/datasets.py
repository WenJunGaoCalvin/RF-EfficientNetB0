import torch
from torchvision import transforms
from torch.utils.data import Dataset
import numpy as np
from torch.utils.data import DataLoader, Subset
from sklearn.model_selection import train_test_split
import os
import tensorflow as tf
from PIL import Image

# Required constants.
ROOT_DIR = '/home/dsta/Desktop/City_Data/Test'
VALID_SPLIT = 0.1
TEST_SPLIT = 0.1
IMAGE_SIZE = 224 # Image size of resize when applying transforms.
BATCH_SIZE = 16 
NUM_WORKERS = 4 # Number of parallel processes for data preparation.

# Training transforms
def get_train_transform(IMAGE_SIZE, pretrained):
    train_transform = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.GaussianBlur(kernel_size=(5, 9), sigma=(0.1, 5)),
        transforms.RandomAdjustSharpness(sharpness_factor=2, p=0.5),
        transforms.ToTensor(),
        normalize_transform(pretrained)
    ])
    return train_transform

# Validation transforms
def get_valid_transform(IMAGE_SIZE, pretrained):
    valid_transform = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(),
        normalize_transform(pretrained)
    ])
    return valid_transform

# Image normalization transforms.
def normalize_transform(pretrained):
    if pretrained: # Normalization for pre-trained weights.
        normalize = transforms.Normalize(
            # mean=[0.485, 0.456, 0.406],
            # std=[0.229, 0.224, 0.225]
            mean=[0.5],
            std=[0.5]
            )
    else: # Normalization when training from scratch.
        normalize = transforms.Normalize(
            # mean=[0.5, 0.5, 0.5],
            # std=[0.5, 0.5, 0.5]
            mean=[0.5],
            std=[0.5]
        )
    return normalize

def read_npy_file(filename):
    spec_width = 1024
    spec_height = 256
    spectrogram = np.load(filename)
    spectrogram = np.reshape(spectrogram,[spec_height, spec_width])
    return spectrogram

class CustomNPYDataset(Dataset):
    def __init__(self, ROOT_DIR, transform=None):
        # self.root_dir = ROOT_DIR
        self.transform = transform
        self.data = []
        self.labels = []
        
        # Load Drone data (class 1)
        drone_path = os.path.join(ROOT_DIR, "Drone")
        for file in os.listdir(drone_path):
            if file.endswith(".npy"):
                self.data.append(os.path.join(drone_path, file))
                self.labels.append(1)
        
        # Load Noise data (class 0)
        noise_path = os.path.join(ROOT_DIR, "Noise")
        for file in os.listdir(noise_path):
            if file.endswith(".npy"):
                self.data.append(os.path.join(noise_path, file))
                self.labels.append(0)
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        filename = self.data[idx]
        npy_file = read_npy_file(filename)
        npy_file = np.stack([npy_file] * 3, axis=-1)
        npy_file = Image.fromarray(npy_file, mode='RGB') # RGB, F
        label = self.labels[idx]
        
        if self.transform:
            npy_file = self.transform(npy_file)
            
        
        return npy_file, label, filename

def get_datasets(pretrained):
    """
    Function to prepare the Datasets with an additional train-test split.
    :param pretrained: Boolean, True or False.
    Returns the training, validation, and test datasets along with the class names.
    """
    dataset = CustomNPYDataset(
        ROOT_DIR, 
        transform=(get_train_transform(IMAGE_SIZE, pretrained))
    )

    dataset_test_val = CustomNPYDataset(
        ROOT_DIR, 
        transform=(get_valid_transform(IMAGE_SIZE, pretrained))
    )
    dataset_size = len(dataset)
    
    # First, split into training and test sets.
    train_indices, test_indices = train_test_split(
        list(range(dataset_size)), test_size=TEST_SPLIT, random_state=42
    )
    dataset_test = Subset(dataset_test_val, test_indices)

    # Now, split the training set into train and validation sets.   
    train_indices, valid_indices = train_test_split(
        train_indices, test_size=VALID_SPLIT/(1-TEST_SPLIT), random_state=42
    )
    
    dataset_train = Subset(dataset, train_indices)
    dataset_valid = Subset(dataset_test_val, valid_indices)
    
    return dataset_train, dataset_valid, dataset_test, ["Noise", "Drone"]

def get_data_loaders(dataset_train, dataset_valid, dataset_test):

    """
    Prepares the training, validation, and test data loaders.
    :param dataset_train: The training dataset.
    :param dataset_valid: The validation dataset.
    :param dataset_test: The test dataset.
    Returns the training, validation, and test data loaders.
    """
    train_loader = DataLoader(
        dataset_train, batch_size=BATCH_SIZE, 
        shuffle=True, num_workers=NUM_WORKERS
    )
    valid_loader = DataLoader(
        dataset_valid, batch_size=BATCH_SIZE, 
        shuffle=False, num_workers=NUM_WORKERS
    )
    test_loader = DataLoader(
        dataset_test, batch_size=BATCH_SIZE, 
        shuffle=False, num_workers=NUM_WORKERS
    )
    return train_loader, valid_loader, test_loader