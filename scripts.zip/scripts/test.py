import torch
from PIL import Image
import numpy as np
from datasets import get_valid_transform, read_npy_file
import os

# Load your model architecture
from torchvision import models

IMAGE_SIZE = 224
pretrained = False

def preprocess(filenames):
    batch = []
    for file in filenames:
        npy_file = read_npy_file(file)
        npy_file = np.stack([npy_file] * 3, axis=-1)
        npy_file = Image.fromarray(npy_file, mode='RGB')
        npy_file = (get_valid_transform(IMAGE_SIZE, pretrained))(npy_file)
        batch.append(npy_file)
    batch_tensor = torch.stack(batch)
    return batch_tensor


def test(model, data):
    with torch.no_grad():       
        image = data
        image = image.to(device)

        # Forward pass.
        outputs = model(image)
        _, preds = torch.max(outputs.data, 1)
        return preds
    
def load_model():
    # Define the model (should match the saved model's architecture)
    model = models.efficientnet_b0(pretrained=False)  # Change to your model
    num_classes = 2  # Set this based on your model
    model.classifier[1] = torch.nn.Linear(model.classifier[1].in_features, num_classes)

    # Load the trained weights
    model.load_state_dict(torch.load("../outputs/model_pretrained_True.pth", map_location=device)["model_state_dict"])
    model.to(device)
    model.eval()  # Set to evaluation mode
    return model
    
# Load Data
ROOT_DIR = '/home/dsta/Desktop/City_Data/Test/samples/'
test_images = [os.path.join(ROOT_DIR, f) for f in os.listdir(ROOT_DIR) if os.path.isfile(os.path.join(ROOT_DIR, f))]

# Set device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = load_model()

test_inputs = preprocess(test_images)
prediction = test(model, test_inputs)
print(f"Predicted Class: {prediction}")