# import tensorflow as tf
# from tensorflow import keras


# def downlink_model(weights=None):
#     model = tf.keras.Sequential()
#     model.add(keras.layers.Conv2D(16, (120,30), padding='same', strides=(1,1), name = 'conv1', data_format="channels_first", input_shape=(1, 256, 1024)))
#     model.add(keras.layers.Activation('relu', name='actv1'))
#     model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), data_format="channels_first", name = 'maxpool1'))
#     model.add(keras.layers.Conv2D(32, (3,3), padding='same', strides=(1,1), name = 'conv2', data_format="channels_first"))
#     model.add(keras.layers.Activation('relu', name='actv2'))
#     model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), data_format="channels_first", name = 'maxpool2'))
#     model.add(keras.layers.Conv2D(64, (3,3), padding='same', strides=(1,1), name = 'conv3', data_format="channels_first"))
#     model.add(keras.layers.Activation('relu', name='actv3'))
#     model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), data_format="channels_first", name = 'maxpool6'))
#     model.add(keras.layers.Lambda(lambda y: tf.reshape(y, [-1,y.shape[1]*y.shape[2]*y.shape[3]])))

#     model.add(keras.layers.Dense(2, activation='softmax',name = 'dense3'))
    
#     if weights is not None:
#         model.load_weights(weights, by_name=True)

#     return model

# def mavlink_model(weights=None):
#     model = tf.keras.Sequential()
#     model.add(keras.layers.Conv2D(16, (3,10), padding='same', strides=(1,1), name = 'conv1', data_format="channels_first", input_shape=(1, 256, 256)))
#     model.add(keras.layers.Activation('relu', name='actv1'))
#     model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), data_format="channels_first", name = 'maxpool1'))
#     model.add(keras.layers.Conv2D(32, (3,3), padding='same', strides=(1,1), name = 'conv2', data_format="channels_first")) 
#     model.add(keras.layers.Activation('relu', name='actv2'))
#     model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), data_format="channels_first", name = 'maxpool2'))
#     model.add(keras.layers.Conv2D(64, (3,3), padding='same', strides=(1,1), name = 'conv3', data_format="channels_first"))
#     model.add(keras.layers.Activation('relu', name='actv3'))
#     model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), data_format="channels_first", name = 'maxpool3'))
#     model.add(keras.layers.Conv2D(256 ,(3,3), padding='same', strides=(1,1), name = 'conv4', data_format="channels_first"))
#     model.add(keras.layers.Activation('relu', name='actv4'))
#     model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), data_format="channels_first", name = 'maxpool4'))
#     model.add(keras.layers.GlobalMaxPooling2D(data_format="channels_first"))  
#     model.add(keras.layers.Dense(256, activation='relu',name = 'dense2'))
#     model.add(keras.layers.Dense(2, activation='softmax',name = 'dense3'))
    
#     if weights is not None:
#         model.load_weights(weights, by_name=True)

#     return model
    
import torch
import torch.nn as nn
import torch.nn.functional as F

class DownlinkModel(nn.Module):
    def __init__(self):
        super(DownlinkModel, self).__init__()
        
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=16, kernel_size=(120, 30), stride=(1, 1), padding='same')
        self.pool1 = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2))
        
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=(3, 3), stride=(1, 1), padding='same')
        self.pool2 = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2))
        
        self.conv3 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(3, 3), stride=(1, 1), padding='same')
        self.pool3 = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2))
        
        self.fc = nn.Linear(64 * (256 // 8) * (1024 // 8), 2)  # Flattened size computation

        self.dropout = nn.Dropout(p=0.2)
        
    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool1(x)
        x = F.relu(self.conv2(x))
        x = self.pool2(x)
        x = F.relu(self.conv3(x))
        x = self.pool3(x)
        
        x = torch.flatten(x, start_dim=1)  # Equivalent to tf.reshape
        x = self.dropout(x)
        x = self.fc(x)
        # x = F.softmax(x, dim=1)
        
        return x
    
def build_model(pretrained=True, fine_tune=True, num_classes=2):
    model = DownlinkModel()
    return model

